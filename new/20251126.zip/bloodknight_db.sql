CREATE DATABASE IF NOT EXISTS bloodknight_db;
USE bloodknight_db;

-- --- RESET: DROP OLD TABLES (To fix "Unknown Column" errors) ---
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS appointment;
DROP TABLE IF EXISTS donation_history;
DROP TABLE IF EXISTS notification;
DROP TABLE IF EXISTS blood_drive;
DROP TABLE IF EXISTS admin;
DROP TABLE IF EXISTS blood_bank;
DROP TABLE IF EXISTS user;
SET FOREIGN_KEY_CHECKS = 1;
-- ---------------------------------------------------------------

-- 1. Entity: USER (Donors)
CREATE TABLE IF NOT EXISTS user (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    blood_type VARCHAR(5),
    phone_number VARCHAR(20),
    total_points INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Entity: BLOOD_BANK (Organizations)
CREATE TABLE IF NOT EXISTS blood_bank (
    bank_id INT AUTO_INCREMENT PRIMARY KEY,
    organization_name VARCHAR(150) NOT NULL,
    address TEXT NOT NULL,
    contact_number VARCHAR(20),
    admin_email VARCHAR(100) NOT NULL
);

-- 3. Entity: ADMIN (New Table for Dashboard Access)
CREATE TABLE IF NOT EXISTS admin (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) DEFAULT 'Officer'
);

-- 4. Entity: BLOOD_DRIVE
CREATE TABLE IF NOT EXISTS blood_drive (
    drive_id INT AUTO_INCREMENT PRIMARY KEY,
    bank_id INT NOT NULL,
    drive_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    location_name VARCHAR(150),
    coordinates VARCHAR(100),
    status ENUM('Upcoming', 'Active', 'Completed') DEFAULT 'Upcoming',
    FOREIGN KEY (bank_id) REFERENCES blood_bank(bank_id) ON DELETE CASCADE
);

-- 5. Entity: APPOINTMENT
CREATE TABLE IF NOT EXISTS appointment (
    appt_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    drive_id INT NOT NULL,
    selected_time TIME NOT NULL,
    status ENUM('Pending', 'Confirmed', 'Completed', 'Cancelled') DEFAULT 'Pending',
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE,
    FOREIGN KEY (drive_id) REFERENCES blood_drive(drive_id) ON DELETE CASCADE
);

-- 6. Entity: NOTIFICATION (Urgent Alerts)
CREATE TABLE IF NOT EXISTS notification (
    alert_id INT AUTO_INCREMENT PRIMARY KEY,
    bank_id INT DEFAULT 1,
    target_blood_type VARCHAR(5),
    message_content TEXT NOT NULL,
    urgency_level ENUM('Low', 'High', 'Critical') DEFAULT 'High',
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 7. Entity: DONATION_HISTORY (Records)
CREATE TABLE IF NOT EXISTS donation_history (
    history_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    drive_id INT,
    donation_date DATE NOT NULL,
    volume_ml INT NOT NULL,
    notes TEXT,
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE
);

-- --- TEST DATA ---

-- Admin User (Password: admin123)
INSERT INTO admin (email, password_hash, full_name, role) VALUES 
('commander@bloodknight.my', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Commander Riza', 'Chief Medical Officer');

-- Sample Donors (Password: password123)
INSERT INTO user (email, password_hash, full_name, blood_type, phone_number) VALUES 
('soldier1@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'John Doe', 'A+', '012-1111111'),
('soldier2@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Smith', 'O-', '012-2222222');

-- Sample Blood Bank
INSERT INTO blood_bank (organization_name, address, contact_number, admin_email) VALUES 
('Central Command (HQ)', 'Jalan Tun Razak', '03-26132688', 'hq@bloodknight.my');

-- Sample Drive
INSERT INTO blood_drive (bank_id, drive_date, start_time, end_time, location_name, status) VALUES 
(1, CURDATE() + INTERVAL 2 DAY, '09:00:00', '17:00:00', 'City Hall Ops Center', 'Upcoming');

-- Sample Appointment
INSERT INTO appointment (user_id, drive_id, selected_time, status) VALUES 
(1, 1, '09:30:00', 'Pending');