<?php
// admin.php - COMMAND CENTER CONTROLLER
header('Content-Type: application/json');
session_start();

require_once 'db_connect.php'; // Ensure you have this file from your previous upload

$action = $_REQUEST['action'] ?? '';

function sendJson($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit;
}

// --- 1. ADMIN AUTHENTICATION ---
if ($action === 'login') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    $stmt = $conn->prepare("SELECT admin_id, password_hash, full_name, role FROM admin WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password_hash'])) {
            $_SESSION['admin_id'] = $row['admin_id'];
            $_SESSION['admin_name'] = $row['full_name'];
            sendJson('success', 'Welcome, Commander.', ['name' => $row['full_name']]);
        } else {
            sendJson('error', 'Access Denied: Invalid Credentials');
        }
    } else {
        sendJson('error', 'Access Denied: User not found');
    }
}

// --- MIDDLEWARE: CHECK LOGIN ---
if (!isset($_SESSION['admin_id'])) {
    sendJson('error', 'Unauthorized Access');
}

// --- 2. DASHBOARD OVERVIEW ---
if ($action === 'get_stats') {
    // Total Donors
    $donors = $conn->query("SELECT COUNT(*) as c FROM user")->fetch_assoc()['c'];
    // Pending Appointments
    $pending = $conn->query("SELECT COUNT(*) as c FROM appointment WHERE status='Pending'")->fetch_assoc()['c'];
    // Total Volume Collected (ml)
    $volume = $conn->query("SELECT SUM(volume_ml) as v FROM donation_history")->fetch_assoc()['v'] ?? 0;
    
    sendJson('success', 'Stats loaded', [
        'donors' => $donors,
        'pending_appt' => $pending,
        'volume_l' => number_format($volume / 1000, 1)
    ]);
}

// --- 3. CREATE BLOOD DRIVE ---
elseif ($action === 'create_drive') {
    $location = $_POST['location'];
    $date = $_POST['date'];
    $start = $_POST['start_time'];
    $end = $_POST['end_time'];
    $bank_id = 1; // Defaulting to HQ for now

    $stmt = $conn->prepare("INSERT INTO blood_drive (bank_id, drive_date, start_time, end_time, location_name) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("issss", $bank_id, $date, $start, $end, $location);
    
    if ($stmt->execute()) sendJson('success', 'Mission Created Successfully');
    else sendJson('error', 'Failed to initiate mission');
}

// --- 4. MANAGE APPOINTMENTS ---
elseif ($action === 'get_appointments') {
    $sql = "SELECT a.appt_id, u.full_name, u.blood_type, d.location_name, a.selected_time, a.status 
            FROM appointment a
            JOIN user u ON a.user_id = u.user_id
            JOIN blood_drive d ON a.drive_id = d.drive_id
            WHERE a.status = 'Pending'
            ORDER BY d.drive_date ASC";
    $result = $conn->query($sql);
    $data = [];
    while ($row = $result->fetch_assoc()) { $data[] = $row; }
    sendJson('success', 'Data loaded', $data);
}

elseif ($action === 'confirm_appt') {
    $id = $_POST['appt_id'];
    $conn->query("UPDATE appointment SET status='Confirmed' WHERE appt_id=$id");
    sendJson('success', 'Appointment Confirmed');
}

// --- 5. PROCESS DONATION (Confirm Blood Donated & Fill Info) ---
elseif ($action === 'process_donation') {
    $email = $_POST['donor_email'];
    $volume = $_POST['volume'];
    $notes = $_POST['notes'];
    $drive_id = $_POST['drive_id'] ?? 0;

    // Find User
    $uStmt = $conn->prepare("SELECT user_id FROM user WHERE email = ?");
    $uStmt->bind_param("s", $email);
    $uStmt->execute();
    $uRes = $uStmt->get_result();

    if ($row = $uRes->fetch_assoc()) {
        $user_id = $row['user_id'];
        $date = date('Y-m-d');

        // Insert Record
        $stmt = $conn->prepare("INSERT INTO donation_history (user_id, drive_id, donation_date, volume_ml, notes) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("iisis", $user_id, $drive_id, $date, $volume, $notes);
        
        if ($stmt->execute()) {
            // Update User Points (e.g., 10 points per donation)
            $conn->query("UPDATE user SET total_points = total_points + 10 WHERE user_id = $user_id");
            sendJson('success', 'Donation processed. Unit secured.');
        } else {
            sendJson('error', 'Database error');
        }
    } else {
        sendJson('error', 'Donor email not found in registry');
    }
}

// --- 6. SEND URGENT ALERT ---
elseif ($action === 'send_alert') {
    $type = $_POST['blood_type']; // e.g., 'O-', 'A+'
    $urgency = $_POST['urgency']; // 'High', 'Critical'
    $msg = $_POST['message'];
    
    $stmt = $conn->prepare("INSERT INTO notification (target_blood_type, message_content, urgency_level) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $type, $msg, $urgency);
    
    if ($stmt->execute()) sendJson('success', 'Broadcasting alert to all units.');
    else sendJson('error', 'Broadcast failed');
}

elseif ($action === 'logout') {
    session_destroy();
    sendJson('success', 'Logged out');
}
?>